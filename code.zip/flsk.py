from flask import Flask, render_template, Response, stream_with_context, jsonify
import cv2
import face_recognition
import numpy as np
import pandas as pd
from datetime import datetime
import os
import dlib
from scipy.spatial import distance as dist
from imutils import face_utils
import queue
import time
import threading
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__)

# --- EMAIL CONFIGURATION ---
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "adarsh12643@gmail.com"
SENDER_PASSWORD = "odaw fpjg szdy yxvm" # Generated from Google App Passwords

# Map student names to their emails
STUDENT_EMAIL_BOOK = {
    "Adarsh_Pratap_Singh": "adarsh12643@gmail.com",
    "Sonam_Singh": "sonam780singh@gmail.com",
    "Shivansh_Pandey": "pshivansh449@gmail.com",
    "Utkarsh_Pandey": "up53pandeyutkarsh@gmail.com"
}

LATE_THRESHOLD_HOUR = 9 

# --- Global State ---
is_running = False
message_queue = queue.Queue()
attendance_data = pd.DataFrame(columns=['Name', 'Time', 'Status'])
ui_attendance_records = [] 
processing_lock = threading.Lock()
output_frame = None
camera_lock = threading.Lock()

# --- Model Initialization ---
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

EYE_AR_THRESH = 0.25 
EYE_AR_CONSEC_FRAMES = 3
KNOWN_ENCODINGS = []
KNOWN_NAMES = []

# --- Utility Functions ---

def send_email_notification(name, status, time_str):
    """Sends a free email notification to the student in a background thread."""
    try:
        recipient_email = STUDENT_EMAIL_BOOK.get(name)
        if not recipient_email: return

        subject = f"Attendance Marked: {status.upper()}"
        body = f"Hello {name},\n\nYour attendance was recorded at {time_str}.\nStatus: {status.upper()}\n\nVerified via Face Recognition Attendance System with Blink Detection."
        
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = SENDER_EMAIL
        msg['To'] = recipient_email

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.send_message(msg)
            print(f"✅ Email sent to {name}")
    except Exception as e:
        print(f"❌ Email Failed: {e}")

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    return (A + B) / (2.0 * C)

def encode_faces(image_folder='known_faces'):
    global KNOWN_ENCODINGS, KNOWN_NAMES
    if not os.path.exists(image_folder): os.makedirs(image_folder)
    for person_name in os.listdir(image_folder):
        person_folder = os.path.join(image_folder, person_name)
        if os.path.isdir(person_folder):
            for img_name in os.listdir(person_folder):
                try:
                    img = face_recognition.load_image_file(os.path.join(person_folder, img_name))
                    enc = face_recognition.face_encodings(img)
                    if enc:
                        KNOWN_ENCODINGS.append(enc[0])
                        KNOWN_NAMES.append(person_name)
                except: continue
    print(f"✅ {len(KNOWN_NAMES)} Face Encodings Loaded.")

# --- Background Processing Worker ---

def camera_worker():
    global output_frame, is_running, ui_attendance_records
    blinks_counter = {}
    cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    while True:
        ret, frame = cap.read()
        if not ret: continue

        if is_running:
            small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            gray = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
            rects = detector(gray, 0)

            for i, rect in enumerate(rects):
                shape = predictor(gray, rect)
                shape = face_utils.shape_to_np(shape)
                ear = (eye_aspect_ratio(shape[lStart:lEnd]) + eye_aspect_ratio(shape[rStart:rEnd])) / 2.0
                
                key = f"face_{i}"
                if key not in blinks_counter: blinks_counter[key] = 0

                if ear < EYE_AR_THRESH:
                    blinks_counter[key] += 1
                else:
                    if blinks_counter[key] >= EYE_AR_CONSEC_FRAMES:
                        # Heavy Recognition triggered by blink
                        rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                        top, right, bottom, left = rect.top(), rect.right(), rect.bottom(), rect.left()
                        encs = face_recognition.face_encodings(rgb_small, [(top, right, bottom, left)])
                        
                        if encs:
                            distances = face_recognition.face_distance(KNOWN_ENCODINGS, encs[0])
                            if len(distances) > 0 and np.min(distances) < 0.5:
                                name = KNOWN_NAMES[np.argmin(distances)]
                                with processing_lock:
                                    if name not in [r['student']['name'] for r in ui_attendance_records]:
                                        now = datetime.now()
                                        status = "present" if now.hour < LATE_THRESHOLD_HOUR else "late"
                                        time_label = now.strftime("%I:%M %p")
                                        
                                        # Record for UI
                                        ui_attendance_records.append({
                                            "student": {"name": name, "id": f"ID-{np.random.randint(100, 999)}"},
                                            "time": time_label, "status": status
                                        })
                                        
                                        # Push UI notification
                                        status_text = "On Time" if status == "present" else "Late"
                                        message_queue.put(f"Attendance Marked: {name}")
                                        
                                        # Async Email
                                        threading.Thread(target=send_email_notification, 
                                                         args=(name, status, time_label)).start()

                    blinks_counter[key] = 0
                
                # Visuals
                t, r, b, l = rect.top()*2, rect.right()*2, rect.bottom()*2, rect.left()*2
                cv2.rectangle(frame, (l, t), (r, b), (0, 255, 0), 2)
                cv2.putText(frame, "Blink to Mark", (l, t-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        with camera_lock:
            output_frame = frame.copy()

# --- Flask Routes ---

@app.route('/')
def index(): return render_template('check.html')

@app.route('/video_feed')
def video_feed():
    def generate():
        while True:
            with camera_lock:
                if output_frame is None: 
                    time.sleep(0.1)
                    continue
                _, buffer = cv2.imencode('.jpg', output_frame)
            yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            time.sleep(0.04)
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/get_attendance_data')
def get_attendance_data():
    global ui_attendance_records, KNOWN_NAMES
    return jsonify({"records": ui_attendance_records, "total_registered": len(KNOWN_NAMES)})

@app.route('/start_attendance')
def start():
    global is_running, ui_attendance_records
    with processing_lock:
        is_running, ui_attendance_records = True, []
    return jsonify(success=True)

@app.route('/stop_attendance')
def stop():
    global is_running
    is_running = False
    return jsonify(success=True)

@app.route('/status_updates')
def status():
    @stream_with_context
    def event_stream():
        while True:
            if not message_queue.empty():
                yield f"data:{message_queue.get()}\n\n"
            time.sleep(0.1)
    return Response(event_stream(), mimetype='text/event-stream')

if __name__ == '__main__':
    encode_faces()
    threading.Thread(target=camera_worker, daemon=True).start()
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)