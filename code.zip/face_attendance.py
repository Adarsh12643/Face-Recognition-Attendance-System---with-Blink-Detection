from flask import Flask, render_template, Response, stream_with_context, jsonify
import cv2
import face_recognition
import numpy as np
import pandas as pd
from datetime import datetime
import os
import dlib
from scipy.spatial import distance as dist
from imutils import face_utils
import queue
import time
import threading

app = Flask(__name__)

# --- Global State and Camera Management ---
is_running = False
# Queue to pass status messages from processing logic to the SSE stream
message_queue = queue.Queue()
attendance_data = pd.DataFrame(columns=['Name', 'Time'])
# Global variable for the single, persistent camera object
camera = None 
processing_lock = threading.Lock() # Lock to ensure only one thread modifies global state

# --- Face Recognition & Blink Detection Logic ---
EYE_AR_THRESH = 0.3
EYE_AR_CONSEC_FRAMES = 3
blinks_counter = {}

# Load dlib's face detector and facial landmark predictor
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

# Get the facial landmark indices for the left and right eyes
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def encode_faces(image_folder='known_faces'):
    # Load known encodings, names, and initialize global data
    global known_encodings, known_names
    known_encodings = []
    known_names = []

    for person_name in os.listdir(image_folder):
        person_folder = os.path.join(image_folder, person_name)
        if os.path.isdir(person_folder):
            for img_name in os.listdir(person_folder):
                img_path = os.path.join(person_folder, img_name)
                try:
                    image = face_recognition.load_image_file(img_path)
                except Exception:
                    continue
                rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                encodings = face_recognition.face_encodings(rgb_image)
                if encodings:
                    known_encodings.append(encodings[0])
                    known_names.append(person_name)

    if known_encodings:
        print("Encodings loaded successfully.")
    else:
        print("No faces were encoded. Please check your 'known_faces' directory.")

def find_and_open_camera(camera_index=0, backend=cv2.CAP_MSMF):
    """
    Manually open a specific camera by index.
    - camera_index: which camera to open (0 = laptop internal cam, 1 = usually external cam).
    - backend: OpenCV backend (CAP_DSHOW for Windows, CAP_V4L2 for Linux, CAP_MSMF also possible).
    """
    global camera

    print(f"Attempting to open camera index {camera_index} with backend {backend}")
    cap = cv2.VideoCapture(camera_index, backend)

    time.sleep(0.5)  # allow hardware time to initialize

    if not cap.isOpened():
        print(f"❌ Error: Could not open camera at index {camera_index} with backend {backend}")
        return False

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 480)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 320)
    camera = cap
    print(f"✅ Webcam initialized successfully at index {camera_index} using backend {backend}")
    return True

def process_frame(frame):
    """Handles all face recognition and blink detection logic."""
    global blinks_counter, attendance_data, is_running
    
    # Check if the attendance system is running before processing a frame
    if not is_running:
        return frame # Return the original frame if not running

    with processing_lock:
        # Check attendance data for non-blocking read
        current_attendees = [row['Name'] for _, row in attendance_data.iterrows()]

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rects = detector(gray, 0)
        
        detected_face_locations = [(r.top(), r.right(), r.bottom(), r.left()) for r in rects]
        detected_face_encodings = face_recognition.face_encodings(frame, detected_face_locations)

        for i, face_encoding in enumerate(detected_face_encodings):
            face_location = detected_face_locations[i]
            
            recognized_name = "Unknown"
            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            if len(face_distances) > 0:
                best_match_index = np.argmin(face_distances)
                if face_distances[best_match_index] < 0.6:
                    recognized_name = known_names[best_match_index]

            name_to_display = "Blink to Mark"
            
            if recognized_name != "Unknown" and recognized_name in current_attendees:
                name_to_display = f"Attendance Marked: {recognized_name}"
            else:
                rect = rects[i]
                shape = predictor(gray, rect)
                shape = face_utils.shape_to_np(shape)
                leftEye = shape[lStart:lEnd]
                rightEye = shape[rStart:rEnd]
                leftEAR = eye_aspect_ratio(leftEye)
                rightEAR = eye_aspect_ratio(rightEye)
                ear = (leftEAR + rightEAR) / 2.0
                
                # Update blink counter logic for the recognized name
                key = recognized_name if recognized_name != "Unknown" else "Unknown" + str(i)
                if key not in blinks_counter:
                    blinks_counter[key] = 0
                    
                if ear < EYE_AR_THRESH:
                    blinks_counter[key] += 1
                else:
                    if blinks_counter[key] >= EYE_AR_CONSEC_FRAMES:
                        if recognized_name != "Unknown":
                            new_row = pd.DataFrame({'Name': [recognized_name], 'Time': [datetime.now().strftime("%Y-%m-%d %H:%M:%S")]})
                            attendance_data = pd.concat([attendance_data, new_row], ignore_index=True)
                            print(f"Attendance marked for {recognized_name}.")
                            message_queue.put(f"Attendance Marked: {recognized_name}")
                            name_to_display = f"Attendance Marked"
                    
                    blinks_counter[key] = 0
            
            # Draw bounding box and text
            top, right, bottom, left = face_location
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name_to_display, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    
    return frame

def stream_video():
    """Yields processed JPEG frames for the video_feed endpoint."""
    global camera, is_running

    if camera is None or not camera.isOpened():
        # Yield a blank/error frame if the camera is not available
        blank_frame = np.zeros((320, 480, 3), dtype=np.uint8)
        cv2.putText(blank_frame, "CAMERA UNAVAILABLE", (150, 240), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)
        ret, buffer = cv2.imencode('.jpg', blank_frame)
        frame_bytes = buffer.tobytes()
        while True:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\r\n' + frame_bytes + b'\r\n')
            time.sleep(1) # Slow down the error stream
        return

    while True:
        ret, frame = camera.read()
        if not ret:
            # If read fails, stop streaming and report error
            message_queue.put("Error: Camera disconnected or stream ended.")
            break
        
        # Process the frame (recognition and drawing happens here)
        processed_frame = process_frame(frame)
        
        # Encode and yield the processed frame
        ret, buffer = cv2.imencode('.jpg', processed_frame)
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        # Add a short delay to prevent high CPU usage
        time.sleep(0.033)

    # Release the camera if streaming breaks unexpectedly
    if camera:
        camera.release()

@app.route('/start_attendance')
def start_attendance():
    global is_running, attendance_data
    with processing_lock:
        if is_running:
            return jsonify(success=False, message="Attendance already running.")
        
        is_running = True
        attendance_data = pd.DataFrame(columns=['Name', 'Time'])
        message_queue.put("Attendance started. Blink to mark presence.")
        return jsonify(success=True, message="Attendance started.")

@app.route('/stop_attendance')
def stop_attendance():
    global is_running
    with processing_lock:
        if not is_running:
            return jsonify(success=False, message="Attendance is not running.")
        
        is_running = False
        
        if not attendance_data.empty:
            attendance_data.to_csv('attendance.csv', index=False)
            print("Attendance saved to attendance.csv.")
        
        message_queue.put("Attendance system stopped. Data saved.")
        return jsonify(success=True, message="Attendance stopped.")

@app.route('/status_updates')
def status_updates():
    @stream_with_context
    def generate_updates():
        while True:
            if not message_queue.empty():
                message = message_queue.get()
                yield f"data:{message}\n\n"
            time.sleep(0.1)

    return Response(generate_updates(), mimetype='text/event-stream')

@app.route('/')
def index():
    return render_template('check.html')

@app.route('/video_feed')
def video_feed():
    # The video feed starts immediately, but the processing only occurs when is_running is True
    return Response(stream_video(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    # 1. Load face encodings
    encode_faces()
    
    # 2. Initialize camera globally
    find_and_open_camera()

    # 3. Run the Flask application
    app.run(debug=True, threaded=True)